package com.System.EmployeeManagement.customException.employee;

public class InputIllegalDataTypeException extends RuntimeException {
	
	public InputIllegalDataTypeException() {
		super();
	}

	public InputIllegalDataTypeException(String msg){
		super(msg);
	}
	
	

}
